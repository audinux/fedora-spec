/* =========================================================================================

   This is an auto-generated file: Any edits you make may be overwritten!

*/

#pragma once

namespace BinaryData
{
    extern const char*   ClearBlueSky_json;
    const int            ClearBlueSky_jsonSize = 15882;

    extern const char*   CompressedOverdrive_json;
    const int            CompressedOverdrive_jsonSize = 15886;

    extern const char*   Heavy_json;
    const int            Heavy_jsonSize = 108183;

    extern const char*   install_requirements_bat;
    const int            install_requirements_batSize = 31;

    extern const char*   install_requirements_sh;
    const int            install_requirements_shSize = 31;

    extern const char*   knob_silver_png;
    const int            knob_silver_pngSize = 325315;

    extern const char*   led_blue_off_png;
    const int            led_blue_off_pngSize = 614;

    extern const char*   led_blue_on_png;
    const int            led_blue_on_pngSize = 1242;

    extern const char*   led_red_off_png;
    const int            led_red_off_pngSize = 828;

    extern const char*   led_red_on_png;
    const int            led_red_on_pngSize = 1192;

    extern const char*   original_off_jpg;
    const int            original_off_jpgSize = 64205;

    extern const char*   original_on_jpg;
    const int            original_on_jpgSize = 64850;

    extern const char*   plot_py;
    const int            plot_pySize = 5987;

    extern const char*   power_switch_down_png;
    const int            power_switch_down_pngSize = 3018;

    extern const char*   Power_switch_off_png;
    const int            Power_switch_off_pngSize = 1047;

    extern const char*   Power_switch_on_png;
    const int            Power_switch_on_pngSize = 956;

    extern const char*   power_switch_up_png;
    const int            power_switch_up_pngSize = 2923;

    extern const char*   requirements_txt;
    const int            requirements_txtSize = 43;

    extern const char*   smp_off_jpg;
    const int            smp_off_jpgSize = 40058;

    extern const char*   smp_on_jpg;
    const int            smp_on_jpgSize = 40147;

    extern const char*   status_knob_png;
    const int            status_knob_pngSize = 40856;

    extern const char*   train_py;
    const int            train_pySize = 11064;

    extern const char*   TubeClean_json;
    const int            TubeClean_jsonSize = 15933;

    extern const char*   TubeDirty_json;
    const int            TubeDirty_jsonSize = 15755;

    extern const char*   Vintage_Knob_png;
    const int            Vintage_Knob_pngSize = 1224149;

    extern const char*   Vintage_Knob_alt_png;
    const int            Vintage_Knob_alt_pngSize = 1116825;

    // Number of elements in the namedResourceList and originalFileNames arrays.
    const int namedResourceListSize = 26;

    // Points to the start of a list of resource names.
    extern const char* namedResourceList[];

    // Points to the start of a list of resource filenames.
    extern const char* originalFilenames[];

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding data and its size (or a null pointer if the name isn't found).
    const char* getNamedResource (const char* resourceNameUTF8, int& dataSizeInBytes);

    // If you provide the name of one of the binary resource variables above, this function will
    // return the corresponding original, non-mangled filename (or a null pointer if the name isn't found).
    const char* getNamedResourceOriginalFilename (const char* resourceNameUTF8);
}

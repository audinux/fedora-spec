#pragma once

#ifndef JucePlugin_LV2URI
 #define JucePlugin_LV2URI "https://www.discodsp.com//plugins/OBXd"
#endif

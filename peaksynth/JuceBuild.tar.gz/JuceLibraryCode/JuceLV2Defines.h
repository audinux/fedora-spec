#pragma once

#ifndef JucePlugin_LV2URI
 #define JucePlugin_LV2URI "https://github.com/owennjpr/JucePeakSynth"
#endif

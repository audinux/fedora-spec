# Welcome to VST SDK 3 public_sdk

Here are located:

- helper classes implementing VST3 Interfaces
- samples of VST3 hosting and VST3 Plug-Ins
- AAX Wrapper
- AU Wrapper
- AUv3 Wrapper
- VST2 Wrapper
- InterAppAudio

## License & Usage guidelines

More details are found at [www.steinberg.net/sdklicenses_vst3](http://www.steinberg.net/sdklicenses_vst3)

/*
   This dummy file is added to the resources section of the project to
   force Xcode to create some resources for the dpm. If there aren't any
   resources, PT will refuse to load the plugin..
*/

